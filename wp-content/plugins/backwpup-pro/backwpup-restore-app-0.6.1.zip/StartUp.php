<?php

/**
 * Restore class for starting the pre packed restore app
 *
 * @author Hans-Helge Buerger
 * @since  2016-02-24
 */
class StartUp {

	/**
	 * @var array holds callback functions for boot process
	 */
	private $callback_chain = array();

	/**
	 * @var string error message set if a callback function exits with an error
	 */
	private $error_message = "";

	/**
	 * StartUp constructor.
	 */
	public function __construct() {
		array_push( $this->callback_chain, 'check_for_file' );
		array_push( $this->callback_chain, 'extract_phar' );
	}

	/**
	 * This function starts the 'boot' process to start the restore app
	 *
	 * The idea is to use a Chain of Responsibility. I.e many different functions are chained and
	 * executed one after another until is successful. This ensures we tried all possibilities and
	 * if everything fails we return an error
	 */
	public function start_up() {
		// Get callback functions of chain
		$chain = $this->get_callback_chain();

		foreach ( $chain as $callback ) {
			$result = call_user_func( array( $this, $callback ) );

			if ( $result['break_loop'] ) {
				break;
			}
		}

		// It seems that every callback in our chain failed. That is sad :(
		// Display an error message in browser for the user.
		if ( $result['success'] ) {
			$this->redirect_to_app();
		} else {
			$this->show_error();
		}
	}

	/**
	 * Getter method for $callback_chain
	 */
	private function get_callback_chain() {
		return $this->callback_chain;
	}

	/**
	 * Function checks if restore module is already extracted and ready
	 *
	 * @return array callback result
	 */
	private function check_for_file() {
		$exists = file_exists( __DIR__ . '/restore/src/App/index.php' );

		return array(
			'break_loop' => $exists,
			'success'    => $exists
		);
	}

	/**
	 * Function checks if PHAR exists and extracts it into __DIR__
	 *
	 * @return array callback result
	 */
	private function extract_phar() {

		if ( ! is_file( __DIR__ . '/restore.phar' ) ) {
			$this->error_message = "The restore module is not found. Please make sure <code>restore.phar</code>"
				. " is in the same directory as <code>StartUp.php</code>";

			return array(
				'break_loop' => true,
				'success'    => false
			);
		}

		if ( ! is_file( __DIR__ . '/restore/README.md' ) ) {
			$phar = new Phar( __DIR__ . '/restore.phar' );
			$phar->extractTo( __DIR__ . '/restore/' );
			unset( $phar );
		}

		return array(
			'break_loop' => true,
			'success'    => true
		);
	}

	/**
	 * Function to redirect user to actual Restore App
	 */
	private function redirect_to_app() {
		// Build path to index.php of restore app
		$path = substr( $_SERVER['REQUEST_URI'], 0, strpos( $_SERVER['REQUEST_URI'], 'startup.php' ) ) . 'restore/src/App/index.php';

		header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		header('Expires: Sat, 26 Jul 1997 05:00:00 GMT'); // past date to encourage expiring immediately

		// Redirect user to restore app
		header( 'HTTP/1.1 303 See other', true, 303 );
		header( 'Location: ' . $path );
		exit;
	}

	/**
	 * Function to display an error message to user if something went wrong
	 */
	private function show_error() {
		echo "<h1>Oh No, Error</h1>";
		echo $this->error_message;
	}
}

// Let's start the restore app
// First create an instance and then star the 'boot' process
$start = new StartUp();
$start->start_up();
